function generateIdeas() {
    const topic = document.getElementById('topicInput').value;
    if (topic.trim() === '') {
        alert('Please enter a topic.');
        return;
    }

    fetch('http://127.0.0.1:5000/generate-ideas', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ topic: topic })
    })
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById('ideaContainer');
        if (data.error) {
            container.innerHTML = `<p>Error: ${data.error}</p>`;
        } else {
            container.innerHTML = `<p><strong>Ideas:</strong> ${data.ideas}</p>`;
        }
    })
    .catch(error => {
        document.getElementById('ideaContainer').innerHTML = `<p>Error: ${error.message}</p>`;
    });
}
