from flask import Flask, request, jsonify, render_template
from transformers import pipeline

app = Flask(__name__)

# Load the model
generator = pipeline('text-generation', model='gpt2')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_ideas():
    topic = request.form['topic']
    prompt = f"Generate five creative ideas for: {topic}"
    response = generator(prompt, max_length=200, num_return_sequences=5)
    ideas = [resp['generated_text'] for resp in response]
    return render_template('index.html', ideas=ideas, topic=topic)

if __name__ == '__main__':
    app.run(debug=True)
